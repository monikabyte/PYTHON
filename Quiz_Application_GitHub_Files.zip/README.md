# Quiz Application Using User-Defined Modules

## Project Description
This is a simple Python Quiz Application developed using user-defined modules and MySQL database connectivity.

## Features
- Displays multiple-choice quiz questions.
- Accepts answers from the user.
- Calculates the score and percentage.
- Uses user-defined Python modules.
- Stores quiz results in a MySQL database.
- Displays the final result.

## Project Structure
- `main.py` - Main program.
- `quiz_module.py` - Quiz questions, quiz logic, and score display.
- `db_module.py` - MySQL database connection and result storage.
- `schema.sql` - Database and table creation queries.
- `requirements.txt` - Required Python package.
- `README.md` - Project documentation.

## Requirements
- Python 3.x
- MySQL Server
- MySQL Command Line Client or MySQL Workbench

## Setup

### 1. Install the Python package
```bash
pip install -r requirements.txt
```

### 2. Create the MySQL database
Open MySQL and run all commands in `schema.sql`.

### 3. Configure database login
Open `db_module.py` and change:
- `user`
- `password`

Example:
```python
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "your_password",
    "database": "quiz_db"
}
```

### 4. Run the application
```bash
python main.py
```

## Modules Used
1. `quiz_module.py` - user-defined module for quiz operations.
2. `db_module.py` - user-defined module for MySQL connectivity.
3. `main.py` - imports and uses the user-defined modules.

## Database Table
The `results` table stores:
- Result ID
- Student name
- Score
- Total questions
- Quiz date

## Note
Do not upload real database passwords to GitHub. Replace the password with a placeholder before committing the project.
