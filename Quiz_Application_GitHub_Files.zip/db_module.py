import mysql.connector
from mysql.connector import Error

DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "your_password",
    "database": "quiz_db"
}

def get_connection():
    try:
        return mysql.connector.connect(**DB_CONFIG)
    except Error as e:
        print("Database connection error:", e)
        return None


def setup_database():
    # Create the database separately using schema.sql before running the program.
    connection = get_connection()
    if connection:
        connection.close()


def save_result(name, score, total):
    connection = get_connection()
    if not connection:
        print("Result was not saved because the database is unavailable.")
        return

    try:
        cursor = connection.cursor()
        query = """
            INSERT INTO results (student_name, score, total_questions)
            VALUES (%s, %s, %s)
        """
        cursor.execute(query, (name, score, total))
        connection.commit()
        print("Result saved successfully to MySQL.")
    except Error as e:
        print("Error saving result:", e)
    finally:
        cursor.close()
        connection.close()
