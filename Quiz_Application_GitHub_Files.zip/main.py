from quiz_module import start_quiz, show_score
from db_module import setup_database, save_result

def main():
    print("\n===== QUIZ APPLICATION =====")
    setup_database()

    name = input("Enter your name: ").strip()
    if not name:
        name = "Guest"

    score, total = start_quiz()
    save_result(name, score, total)
    show_score(name, score, total)

if __name__ == "__main__":
    main()
