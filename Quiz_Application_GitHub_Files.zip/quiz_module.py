QUESTIONS = [
    {
        "question": "Which language is mainly used for this quiz application?",
        "options": ["Python", "HTML", "CSS", "SQL"],
        "answer": 1
    },
    {
        "question": "Which keyword is used to define a function in Python?",
        "options": ["function", "def", "fun", "define"],
        "answer": 2
    },
    {
        "question": "Which data type stores True or False in Python?",
        "options": ["int", "str", "bool", "list"],
        "answer": 3
    },
    {
        "question": "Which command is used to display output in Python?",
        "options": ["print()", "display()", "show()", "output()"],
        "answer": 1
    },
    {
        "question": "Which database is used by this project?",
        "options": ["MySQL", "MongoDB", "Oracle", "SQLite"],
        "answer": 1
    }
]

def start_quiz():
    score = 0

    print("\n----- QUIZ START -----")
    for number, q in enumerate(QUESTIONS, start=1):
        print(f"\nQ{number}. {q['question']}")
        for i, option in enumerate(q["options"], start=1):
            print(f"{i}. {option}")

        while True:
            try:
                choice = int(input("Enter your answer (1-4): "))
                if 1 <= choice <= 4:
                    break
                print("Please enter a number from 1 to 4.")
            except ValueError:
                print("Please enter a valid number.")

        if choice == q["answer"]:
            print("Correct!")
            score += 1
        else:
            print(f"Wrong. Correct answer: {q['options'][q['answer'] - 1]}")

    return score, len(QUESTIONS)


def show_score(name, score, total):
    percentage = (score / total) * 100 if total else 0
    print("\n===== QUIZ RESULT =====")
    print(f"Name       : {name}")
    print(f"Score      : {score}/{total}")
    print(f"Percentage : {percentage:.2f}%")
